// TODO: Declare any global variables we need

// Image
const mainImage = document.createElement("img");
mainImage.src = "https://www.pngkey.com/png/full/955-9551770_drake-png-transparent-images-desktop-backgrounds-drake-head.png";
mainImage.setAttribute("id", "mainImageId")
document.querySelector("#contentData").appendChild(mainImage);
mainImage.style.height = "300px";


// FLIP Button
const flipButton = document.createElement("button");
flipButton.setAttribute("id", "flipButton");
flipButton.innerHTML = "Flip";
document.querySelector("#contentData").appendChild(flipButton);


// CLEAR Button
const clearButton = document.createElement("button");
clearButton.setAttribute("id", "clearButton")
clearButton.innerHTML = "Clear";
document.querySelector("#contentData").appendChild(clearButton);

// STATUS Message
const statusMessage = document.createElement("h2");
statusMessage.setAttribute("id", "statusMessage");
statusMessage.innerHTML = "Let's Get to Flipping";
document.querySelector("#contentData").appendChild(statusMessage);


var heads = 0;
var tails = 0;

document.addEventListener('DOMContentLoaded', function () {
    // TODO: Add event listener and handler for flip and clear buttons

    // Flip Button Click Handler
        // TODO: Determine flip outcome
        // TODO: Update image and status message in the DOM

        // Update the scorboard
        // TODO: Calculate the total number of rolls/flips
        // Make variables to track the percentages of heads and tails
        // TODO: Use the calculated total to calculate the percentages
        // HINT: Make sure not to divide by 0! (if total is 0, percent will be 0 as well)
        // TODO: Update the display of each table cell
        function flipButtonFunction(){
            var images = ["https://www.pngkey.com/png/full/955-9551770_drake-png-transparent-images-desktop-backgrounds-drake-head.png", "http://www.textures4photoshop.com/tex/thumbs/devil-tail-PNG-image-thumb20.png"];
            var random = images[Math.floor(Math.random() * images.length)];

            document.getElementById("mainImageId").src = random;

            if(random == images[0]){
                heads = heads + 1;
                document.querySelector("#headsTab").textContent = heads;
                statusMessage.innerHTML = "you got HEADS";
                console.log("Heads: " + heads)
            } else if (random == images[1]){
                tails = tails + 1;
                document.querySelector("#tailsTab").textContent = tails;
                statusMessage.innerHTML = "you got TAILS";
                console.log("Tails: " + tails);
            }

            let percentHeads = 0;
            let percentTails = 0;
            let total = heads + tails;

            if (total > 0) {
                // Calculate percentage of heads and tails
                percentHeads = Math.round((heads / total) * 100)
                percentTails = Math.round((tails / total) * 100)
            }

            document.querySelector("#heads-percent").textContent = percentHeads + "%";
            document.querySelector("#tails-percent").textContent = percentTails + "%";
        }
        
        flipButton.addEventListener("click", flipButtonFunction);

    // Clear Button Click Handler
        // TODO: Reset global variables to 0
        // TODO: Update the scoreboard (same logic as in flip button click handler)
        function clearButtonFunction(){
            heads = 0;
            tails = 0;

            document.querySelector("#heads-percent").textContent = heads + "%";
            document.querySelector("#tails-percent").textContent = tails + "%";
            document.querySelector("#tailsTab").textContent = tails;
            document.querySelector("#headsTab").textContent = heads;

            statusMessage.innerHTML = "Let's Get to Flipping";

            console.log("-----------------------")
            console.log("Heads:" + heads)
            console.log("Tails:" + tails)
        }
        
        clearButton.addEventListener("click", clearButtonFunction);
})